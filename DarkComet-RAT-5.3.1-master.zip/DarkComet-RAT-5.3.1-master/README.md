# DarkComet-RAT-5.3.1
DarkComet RAT(RemoteAdministrationTool) 5.3.1

pull of the DarkComet RAT.
this version works with wine on linux with no problems.

ToDo (windows):
  - extract zip file
  - run DarkComet.exe
  
ToDo (linux):
  - extract zip file
  - right click in 
  - open terminal in DarkComet folder
  - enter command 'wine DarkComet.exe'
